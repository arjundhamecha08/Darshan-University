const moviesData = [
    {
        id: 1,
        title: "Inception",
        poster: "assets/Movies/Inception.jpg",
        genre: "Sci-Fi",
        year: 2010,
        language: "English",
        duration: "2h 28m",
        director: "Christopher Nolan",
        cast: ["Leonardo DiCaprio", "Tom Hardy"],
        rating: 8.8,
        description: "A thief enters people's dreams to steal secrets.",
        trailer: "https://www.youtube.com/results?search_query=Inception+official+trailer"
    },

    {
        id: 2,
        title: "Interstellar",
        poster: "assets/Movies/Interstellar.jpg",
        genre: "Sci-Fi",
        year: 2014,
        language: "English",
        duration: "2h 49m",
        director: "Christopher Nolan",
        cast: ["Matthew McConaughey", "Anne Hathaway"],
        rating: 8.7,
        description: "Explorers travel through space to find a future for humanity.",
        trailer: "https://www.youtube.com/results?search_query=Interstellar+official+trailer"
    },

    {
        id: 3,
        title: "3 Idiots",
        poster: "assets/Movies/3_Idiots.jpg",
        genre: "Comedy",
        year: 2009,
        language: "Hindi",
        duration: "2h 50m",
        director: "Rajkumar Hirani",
        cast: ["Aamir Khan", "R. Madhavan"],
        rating: 8.4,
        description: "Three engineering students challenge traditional education.",
        trailer: "https://www.youtube.com/results?search_query=3+Idiots+official+trailer"
    },

    {
        id: 4,
        title: "The Dark Knight",
        poster: "assets/Movies/The_Dark_Knight.jpg",
        genre: "Action",
        year: 2008,
        language: "English",
        duration: "2h 32m",
        director: "Christopher Nolan",
        cast: ["Christian Bale", "Heath Ledger"],
        rating: 9.0,
        description: "Batman faces a dangerous criminal known as the Joker.",
        trailer: "https://www.youtube.com/results?search_query=The+Dark+Knight+official+trailer"
    },

    {
        id: 5,
        title: "Animal",
        poster: "assets/animal.jpg",
        genre: "Action",
        year: 2023,
        language: "Hindi",
        duration: "3h 21m",
        director: "Sandeep Reddy Vanga",
        cast: ["Ranbir Kapoor", "Anil Kapoor"],
        rating: 6.2,
        description: "A violent crime drama centered on a complicated father-son relationship.",
        trailer: "https://www.youtube.com/results?search_query=Animal+2023+official+trailer"
    }
];
