//Theme Button
const theme = document.getElementById("theme");
const themeIcon = document.getElementById("theme-img");

if (theme && themeIcon) {
  theme.addEventListener("click", function () {
    document.body.classList.toggle("dark-mode");

    if (document.body.classList.contains("dark-mode")) {
      themeIcon.src = "assets/moon.png";
    } else {
      themeIcon.src = "assets/sun.png";
    }
  });
}



function displayMovieCards(movieList = moviesData) {
  const container = document.getElementById("Movies");

  if (!container) return;

  container.innerHTML = "";

  if (movieList.length === 0) {
    container.innerHTML = "<p class='no-results'>No movies found.</p>";
    return;
  }

  movieList.forEach(function (movie) {
    const card = document.createElement("div");
    card.classList.add("top");

    const image = document.createElement("img");
    image.src = movie.poster;
    image.alt = movie.title;

    const title = document.createElement("h3");
    title.textContent = movie.title;

    const genre = document.createElement("p");
    genre.textContent = "Genre: " + movie.genre;

    const year = document.createElement("p");
    year.textContent = "Year: " + movie.year;

    const rating = document.createElement("p");
    rating.textContent = "⭐ " + movie.rating;

    const btn = document.createElement("button");
    btn.id = "dynamic-btn";
    btn.textContent = "Add to Cart";
    btn.addEventListener("click", function (e) {
      addToCart(movie.id);
    });

    const view = document.createElement("button");
    view.id = "dynamic-btn";
    view.textContent = "View Details";
    view.addEventListener("click", function (e) {
      window.location.href = "movie-details.html?id=" + movie.id;
      movieDetails(movie.id);
    });



    card.append(image, title, genre, year, rating, btn, view);
    container.appendChild(card);
  });
}

function movieDetails() {
  const id = Number(new URLSearchParams(window.location.search).get("id"));
  const movie = moviesData.find(m => m.id === id);
  const container = document.getElementById("movie-details");

  if (!movie || !container) return;

  container.innerHTML = `
    <img src="${movie.poster}" alt="${movie.title}">
    <h1>${movie.title}</h1>
    <p>Genre: ${movie.genre}</p>
    <p>Year: ${movie.year}</p>
    <p>Rating: ⭐ ${movie.rating}</p>
    <p>${movie.description}</p>
  `;
}

movieDetails();

let cart = [];
function addToCart(movieId) {
  const movie = moviesData.find(function (m) {
    return m.id === movieId;
  });

  if (!movie) return;

  cart.push(movie);

  console.log("Cart:", cart);
  alert(movie.title + " added to cart!");
}


function filterGenre(genre) {
  window.location.href = "movies.html?genre=" + genre;
}
let params = new URLSearchParams(window.location.search);
let selectedGenre = params.get("genre");

if (selectedGenre) {
    let result = moviesData.filter(function(movie) {
        return movie.genre.toLowerCase() === selectedGenre.toLowerCase();
    });

    displayMovieCards(result);
} else {
    displayMovieCards(moviesData);
}





const searchInput = document.getElementById("search-input");

function handleSearch() {

  // Search on Enter key
  if (searchInput) {
    searchInput.addEventListener("keydown", function (event) {
      if (event.key === "Enter") {
        const searchText = searchInput.value.trim();

        window.location.href =
          "movies.html?search=" + encodeURIComponent(searchText);
      }
    });
  }

  const container = document.getElementById("Movies");

  if (!container || typeof moviesData === "undefined") {
    return;
  }

  const params = new URLSearchParams(window.location.search);

  const category = params.get("category");
  const selectedGenre = params.get("genre");
  const searchText = (params.get("search") || "").toLowerCase().trim();

  let movieResults = moviesData;

  // Language filter
  if (category) {
    movieResults = movieResults.filter(function (movie) {
      return movie.language &&
        movie.language.toLowerCase() === category.toLowerCase();
    });
  }

  // Genre filter
  if (selectedGenre) {
    movieResults = movieResults.filter(function (movie) {
      return movie.genre &&
        movie.genre.toLowerCase() === selectedGenre.toLowerCase();
    });
  }

  // Search by movie title
  if (searchText) {
    movieResults = movieResults.filter(function (movie) {
      return movie.title.toLowerCase().includes(searchText);
    });
  }

  // Display final movies
  displayMovieCards(movieResults);

  // Keep search text in input
  if (searchInput) {
    searchInput.value = params.get("search") || "";
  }
}

handleSearch();


// Genre filter function
function filterGenre(genre) {
  const params = new URLSearchParams(window.location.search);

  params.set("genre", genre);

  window.location.href = "movies.html?" + params.toString();
}



function renderMovies(containerId, movieNames, folderName) {
  let container = document.getElementById(containerId);

  if (!container) {
    return;
  }

  for (let movieName of movieNames) {
    let movie = document.createElement("div");
    let image = document.createElement("img");
    movie.classList.add("top");
    image.src = `assets/${folderName}/${movieName}`;
    movie.appendChild(image);
    container.appendChild(movie);
  }
}

// HighRated_Movie

let HighRated_Movies = [
  "The_Shawshank_Redemption.jpg",
  "The_God_Father.jpg",
  "The_Dark_Knight.jpg",
  "The_Lord_of_Rings.jpg",
  "Schindlers_List.jpg",
];

renderMovies("high-rated", HighRated_Movies, "High_Rated_Movies");

let Featured_Movies = [
  "Inception.jpg",
  "Interstellar.jpg",
  "The_Dark_Knight.jpg",
  "The_Shawshank_Redemption.jpg",
  "Avengers_Endgame.jpg",
  "3_Idiots.jpg",
];
renderMovies("featured", Featured_Movies, "Featured_Movies");

//Top Trending Movie

let TopTrending_Movies = [
  "Dhurandhar.jpg",
  "Dhamaal_4.jpg",
  "Welcome_To_The_Jungle.jpg",
  "Bhoot_Bangla.jpg",
  "Cocktail_2.jpg",
  "Alpha.jpg",
  "The_Dog_Star.jpg",
  "The_Odyssey.jpg",
  "The_whisper_man.jpg",
];

renderMovies("trending", TopTrending_Movies, "Top_Trending_Movies");

//Fav-Movies
let Fev_Movies = ["animal.jpg"];
renderMovies("fev-movies", Fev_Movies, "Fev_Movies");

//Movies
// let Movies = TopTrending_Movies.concat(Featured_Movies).concat(HighRated_Movies)
// renderMovies("Movies", Movies, "Movies");
