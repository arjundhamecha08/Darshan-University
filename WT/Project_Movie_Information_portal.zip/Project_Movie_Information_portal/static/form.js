function loginValidation() {
    const emailInput = document.getElementById('login-email');
    const passwordInput = document.getElementById('login-password');
    const loginError = document.getElementById('login-error');
    const passwordError = document.getElementById('password-error');

    let isValid = true;

    // Validate email/username
    if (emailInput.value.trim() === '') {
        loginError.textContent = 'Email or username is required.';
        isValid = false;
    } else {
        loginError.textContent = '';
    }

    // Validate password
    if (passwordInput.value.trim() === '') {
        passwordError.textContent = 'Password is required.';
        isValid = false;
    } else {
        passwordError.textContent = '';
    }

    return isValid;
}


function registrationValidation() {
    const nameInput = document.getElementById('name');
    const emailInput = document.getElementById('email');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirm-password');

    const nameError = document.getElementById('name-error');
    const emailError = document.getElementById('email-error');
    const usernameError = document.getElementById('username-error');
    const passwordError = document.getElementById('password-error');
    const confirmPasswordError = document.getElementById('confirm-password-error');

    let isValid = true;

    // Validate name
    if (nameInput.value.trim() === '') {
        nameError.textContent = 'Name is required.';
        isValid = false;
    } else {
        nameError.textContent = '';
    }

    // Validate email
    if (emailInput.value.trim() === '') {
        emailError.textContent = 'Email is required.';
        isValid = false;
    } else {
        emailError.textContent = '';
    }

    // Validate username

    let usernameRegex = /^[a-z0-9_]{3,20}$/;
    if (usernameInput.value.trim() === '') {
        usernameError.textContent = 'Username is required.';
        isValid = false;
    } else if (!usernameRegex.test(usernameInput.value)) {
        usernameError.textContent = 'Username can only contain lowercase letters, numbers, and underscores.';
        isValid = false;
    } else {
        usernameError.textContent = '';
    }

   let Passregex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[^A-Za-z0-9]).{8,}$/;
    if (!Passregex.test(passwordInput.value)) {
        passwordError.textContent = 'Password must contain at least one uppercase letter, one lowercase letter, one digit, and one special character.';
        isValid = false;
    }

    
    // Validate confirm password
    if (confirmPasswordInput.value.trim() === '') {
        confirmPasswordError.textContent = 'Please confirm your password.';
        isValid = false;
    } else if (passwordInput.value !== confirmPasswordInput.value) {
        confirmPasswordError.textContent = 'Passwords do not match.';
        isValid = false;
    } else {
        confirmPasswordError.textContent = '';
    }

    return isValid;
}